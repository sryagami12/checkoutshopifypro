<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        .fkHeader {
            padding-top: 15%;
            padding-bottom: 25%;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="fkHeader">
        <h3>Please Publish Your Site To Go Live!</h3>
    </div>
<div data-cc-link-attribution="true"><a href="https://checkoutchamp.com" title="Powered by CheckoutChamp"></a></div></body>
</html>